#ifndef ERRORCODE_H
#define ERRORCODE_H
enum Error_code
{
    duplicate_error,
    not_present,
    success
};
#endif
